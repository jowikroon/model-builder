#!/usr/bin/env python3
"""
Samantha AI - Local Backend Server
Advanced conversational AI with learning capabilities
"""

import asyncio
import os
import sys
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from loguru import logger

# Add the current directory to Python path
sys.path.append(str(Path(__file__).parent))

from core.config import settings
from core.database import init_db
from core.llm_manager import LLMManager
from core.learning_engine import LearningEngine
from core.prompt_classifier import PromptClassifier
from api.routes import chat, health, models, learning, integrations


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    logger.info("🚀 Starting Samantha AI Backend...")
    
    # Initialize database
    await init_db()
    logger.info("✅ Database initialized")
    
    # Initialize LLM Manager
    app.state.llm_manager = LLMManager()
    await app.state.llm_manager.initialize()
    logger.info("✅ LLM Manager initialized")
    
    # Initialize Learning Engine
    app.state.learning_engine = LearningEngine()
    await app.state.learning_engine.initialize()
    logger.info("✅ Learning Engine initialized")
    
    # Initialize Prompt Classifier
    app.state.prompt_classifier = PromptClassifier()
    await app.state.prompt_classifier.initialize()
    logger.info("✅ Prompt Classifier initialized")
    
    logger.info("🎉 Samantha AI Backend is ready!")
    
    yield
    
    # Cleanup
    logger.info("🛑 Shutting down Samantha AI Backend...")
    if hasattr(app.state, 'llm_manager'):
        await app.state.llm_manager.cleanup()
    logger.info("👋 Goodbye!")


# Create FastAPI application
app = FastAPI(
    title="Samantha AI Backend",
    description="Advanced conversational AI with learning capabilities",
    version="2.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(health.router, prefix="/api", tags=["health"])
app.include_router(chat.router, prefix="/api", tags=["chat"])
app.include_router(models.router, prefix="/api", tags=["models"])
app.include_router(learning.router, prefix="/api", tags=["learning"])
app.include_router(integrations.router, prefix="/api", tags=["integrations"])

# Serve static files (if any)
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Samantha AI Backend",
        "version": "2.0.0",
        "status": "running",
        "message": "Hello! I'm Samantha, your personal AI assistant."
    }


if __name__ == "__main__":
    # Configure logging
    logger.remove()
    logger.add(
        sys.stdout,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        level="INFO"
    )
    logger.add(
        "logs/samantha.log",
        rotation="10 MB",
        retention="7 days",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        level="DEBUG"
    )
    
    # Run the server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_config=None  # Use loguru instead
    )

